import Logo from './logo.png';
import GrayPic from './gray-pic.png';
import DownArrow from './down-arrow.png';
import BackgroundImage from './background_image.png';

export {
    Logo, GrayPic, DownArrow, BackgroundImage
}